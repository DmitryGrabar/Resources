package chat;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;
import java.io.StringReader;

public class Message {

    private long id;

    private String text;

    private String author;

    private String timestamp;

    public Message(String JSONData) {
        JsonReader reader = Json.createReader(new StringReader(JSONData));
        JsonObject messageObject = reader.readObject();
        reader.close();

        id = messageObject.getJsonNumber("id").longValue();
        text = messageObject.getString("text");
        author = messageObject.getString("author");
        timestamp = messageObject.getString("timestamp");
    }

    public Message(String msg, String timestamp) {
        String[] splitMsg = msg.split(" ");
        String[] splitTime = timestamp.split(" |/|:");
        String id = "";
        this.text = "";
        for(int i = 1; i < splitMsg.length; i++) {
            this.text += splitMsg[i] + " ";
        }
        this.author = splitMsg[0].substring(1, splitMsg[0].length() - 1);
        this.timestamp = timestamp;
        for(String token : splitTime) {
            if(token.length() == 1) {
                token = "0" + token;
            }
            id += token;
        }
        this.id = new Long(id);
    }

    @Override
    public String toString() {
        return id + " [" + author + "] " + text + timestamp;
    }

    public long getId() {
        return id;
    }

    public String getText() {
        return text;
    }

    public String getAuthor() {
        return author;
    }

    public String getTimestamp() {
        return timestamp;
    }
}
