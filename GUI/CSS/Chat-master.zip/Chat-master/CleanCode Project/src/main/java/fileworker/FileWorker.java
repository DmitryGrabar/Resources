package fileworker;

import chat.Message;
import javax.json.Json;
import javax.json.JsonObject;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Scanner;

public class FileWorker {

    private List<Message> history;

    public FileWorker(List<Message> history) {
        this.history = history;
    }

    public void loadHistory() {
        Scanner scanner;
        try {
            scanner = new Scanner(new File("history.txt").getAbsoluteFile());
            while (scanner.hasNext()) {
                history.add(new Message(scanner.nextLine()));
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void saveHistory() {
        File outFile = new File("history.txt");
        try {
            outFile.createNewFile();
            PrintWriter out = new PrintWriter(outFile.getAbsoluteFile());
            for(Message msg : history) {
                out.println(createJsonMessageObject(msg));
            }
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private JsonObject createJsonMessageObject(Message message) {
        JsonObject messageObject = Json.createObjectBuilder()
                .add("id", message.getId())
                .add("text", message.getText())
                .add("author", message.getAuthor())
                .add("timestamp", message.getTimestamp())
                .build();
        return messageObject;
    }
}
