package chat;

import java.io.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import fileworker.FileWorker;
import searcher.Searcher;

public class Chat {
    List<Message> history;
    FileWriter logOut;
    FileWorker fileWorker;
    Searcher searcher;

    Chat() {
        history = new ArrayList<>();
        fileWorker = new FileWorker(history);
        loadHistory();
        searcher = new Searcher(history);
        try {
            logOut = new FileWriter("log.txt", true);
        } catch (IOException e) {
            e.getMessage();
        }
    }

    public static void main(String[] args) {
        Chat chat = new Chat();
        System.out.println("Welcome to \"chat.chat 1.0\":");
        chat.displayHelp();
        chat.run();
    }

    private void run() {
        Scanner scanner = new Scanner(System.in);
        while(true) {
            String msg = scanner.nextLine();
            execute(msg);
        }
    }

    private void loadHistory() {
        fileWorker.loadHistory();
    }

    private void saveHistory() {
        fileWorker.saveHistory();
    }

    private void execute(String msg) {
        String[] commands = msg.split(" ");
        String badFormat = "Unknown message format.";
        try {
            switch (commands[0]) {
                case "/?":
                    if (commands.length == 1) {
                        logOut.write("/? Display help " + currentDate() + "\n");
                        displayHelp();
                    } else {
                        throw new BadFormatException(badFormat);
                    }
                    return;

                case "/h":
                    if (commands.length == 1) {
                        displayHistory();
                    } else {
                        throw new BadFormatException(badFormat);
                    }
                    return;

                case "/s":
                    if (commands.length == 1) {
                        saveHistory();
                        logOut.close();
                        System.exit(0);
                    } else {
                        throw new BadFormatException(badFormat);
                    }
                    return;

                case "/d":
                    if (commands.length == 2) {
                        deleteMessage(new Long(commands[1]));
                    } else {
                        throw new BadFormatException(badFormat);
                    }
                    return;

                case "/sa":
                    if (commands.length == 2) {
                        searchByAuthor(commands[1]);
                    } else {
                        throw new BadFormatException(badFormat);
                    }
                    return;

                case "/sk":
                    if (commands.length == 2) {
                        searchByKeyword(commands[1]);
                    } else {
                        throw new BadFormatException(badFormat);
                    }
                    return;

                case "/sr":
                    searchByRegEx(msg.substring(4));
                    return;

                case "/hp":
                    if(msg.matches("/hp \\d{4}/\\d{2}/\\d{2} \\d{2}:\\d{2}:\\d{2} -" +
                            " \\d{4}/\\d{2}/\\d{2} \\d{2}:\\d{2}:\\d{2}"))
                    searchByTimePeriod(msg);
                    return;

                default:
                    if (msg.matches("\\[.+\\] : .+")) {
                        history.add(new Message(msg, currentDate()));
                        logOut.write("chat.Message added to the story " + currentDate() + "\n");
                    } else {
                        logOut.write(badFormat + " " + currentDate());
                        throw new BadFormatException(badFormat);
                    }
                    return;
            }
        } catch (BadFormatException e) {
            try {
                logOut.write(badFormat + " " + currentDate() + "\n");
            } catch (IOException e1) {
            }
            System.out.println(e.getMessage());
        } catch (NumberFormatException e) {
            System.err.println(badFormat);
        } catch (IOException e) {
            e.getMessage();
        }
    }

    private String currentDate() {
        Date date = new Date();
        return (date.getYear() + 1900) + "/" + (date.getMonth() + 1) + "/" + date.getDate() +
                " " + date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();
    }

    private void displayHistory() throws IOException {
        logOut.write("/h View history " + currentDate() + "\n");
        System.out.println("History format: id [author] : message date");
        for(Message msg : history) {
            System.out.println(msg);
        }
    }

    private void deleteMessage(long id) throws IOException {
        logOut.write("/d Deleting message id = " + id + " " + currentDate() + "\n");
        for(Message msg : history) {
            if(msg.getId() == id) {
                history.remove(msg);
                System.out.println("Successful deletion.");
                logOut.write("Successful deletion.\n");
                return;
            }
        }
        System.err.println("Messages with this id not found.");
        logOut.write("Messages with this id not found\n");
    }

    private void searchByAuthor(String author) throws IOException {
        logOut.write("/sa Search in the history of messages by author " + author + " " + currentDate() + "\n");
        logOut.write("Found " + searcher.searchByAuthor(author) + " messages\n");
    }

    private void searchByKeyword (String keyword) throws IOException {
        logOut.write("/sk Search in the history of messages by keyword " + keyword + " " + currentDate() + "\n");
        logOut.write("Found " + searcher.searchByKeyword(keyword) + " messages\n");
    }

    private void searchByRegEx(String regex) throws IOException {
        logOut.write("/sr Search in the history of messages by a regular expression ^"
                + regex + " " + currentDate() + "?\n");
        logOut.write("Found " + searcher.searchByRegEx(regex) + " messages\n");
    }

    private void searchByTimePeriod(String period) throws IOException {
        logOut.write("/sr View history of messages for a certain period " + period + " " + currentDate() + "\n");
        logOut.write("Found " + searcher.searchByTimePeriod(period) + " messages\n");
    }

    private void displayHelp () {
        System.out.println("/? - Display help.");
        System.out.println("/s - Save history and exit.");
        System.out.println("/h - View history of messages.");
        System.out.println("/d *id* - Delete the message by id.");
        System.out.println("/sa *author* - Search in the history of messages by author.");
        System.out.println("/sk *keyword* - Search in the history of messages by keyword.");
        System.out.println("/sr *regular expression* - Search in the history of messages by a regular expression.");
        System.out.println("/hp *yyyy/mm/dd hh:mm:ss - yyyy/mm/dd hh:mm:ss* - View history of messages for a certain period.");
        System.out.println("Messages format: [Author] : message");
    }
}
