package chat;

public class BadFormatException extends Exception {

    public BadFormatException(String message) {
        super(message);
    }
}
