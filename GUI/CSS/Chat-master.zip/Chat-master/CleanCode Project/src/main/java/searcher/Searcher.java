package searcher;

import chat.Message;

import java.io.IOException;
import java.util.List;

public class Searcher {

    List<Message> history;

    public Searcher(List<Message> history) {
        this.history = history;
    }

    public int searchByAuthor(String author) throws IOException {
        int n = 0;
        System.out.println("All " + author + "'s messages:");
        for(Message msg : history) {
            if(msg.getAuthor().compareTo(author) == 0) {
                System.out.println(msg);
                n++;
            }
        }
        return n;
    }

    public int searchByKeyword (String keyword) throws IOException {
        int n = 0;
        System.out.println("All messages with \"" + keyword + "\":");
        for (Message msg : history) {
            if(msg.getText().contains(keyword)) {
                System.out.println(msg);
                n++;
            }
        }
        return n;
    }

    public int searchByRegEx(String regex) throws IOException {
        int n = 0;
        System.out.println("All messages that match ^" + regex + "?:");
        for (Message msg : history) {
            if(msg.getText().substring(2, msg.getText().length() - 2).matches(regex)) {
                System.out.println(msg);
                n++;
            }
        }
        return n;
    }

    public int searchByTimePeriod(String period) throws IOException {
        int n = 0;
        String[] splitPeriod = period.split(" ");
        long startTime = timeToLong(splitPeriod[1] + " " + splitPeriod[2]);
        long endTime = timeToLong(splitPeriod[4] + " " + splitPeriod[5]);
        if(endTime < startTime) {
            System.err.println("Invalid period");
        }

        System.out.println("All messages between " + period + ":");
        for(Message msg : history) {
            if(msg.getId() > startTime) {
                if(msg.getId() < endTime) {
                    System.out.println(msg);
                    n++;
                } else {
                    return n;
                }
            }
        }
        return n;
    }

    private long timeToLong(String time) {
        String[] splitPeriod = time.split(" |:|/");
        String str = "";
        for(String s : splitPeriod) {
            str += s;
        }
        return new Long(str);
    }
}
