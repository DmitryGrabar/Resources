var messages = [];

window.onload = function onload() {
	var conditionImg = document.getElementsByClassName('condition')[0];
	conditionImg.src = "offline.png";
	
	var msgHistory = restore("Messages");
	createAllMessages(msgHistory);
	
	document.getElementById('nickname').value = restore("Nickname");
};

function createAllMessages(msgHistory) {
	for(var i = 0; i < msgHistory.length; i++)
		addMsg(msgHistory[i]);
}

function save_nick(elem) {
	store(elem.value, "Nickname");
}

function delete_msg(elem) {
	var msg = elem.parentElement;
	msg.className = "message deleted";
	msg.getElementsByClassName('text')[0].innerHTML = 'Deleted!';
	msg.removeChild(msg.getElementsByClassName('message-edit')[0]);
	msg.removeChild(msg.getElementsByClassName('message-delete')[0]);
}

function edit_msg(elem) {
	var msg = elem.parentElement;
	msg.getElementsByClassName("edit_area")[0].className = "edit_area_on";
	var edit_field = msg.getElementsByClassName('edit-field')[0];
	edit_field.value = msg.getElementsByClassName('text')[0].innerHTML;
}

function confirm_change(elem) {
	var msg = elem.parentElement.parentElement;
	var changedText = elem.parentElement.getElementsByClassName('edit-field')[0].value;
	msg.getElementsByClassName('text')[0].innerHTML = changedText;
	elem.parentElement.className = "edit_area";
}

function send_msg() {
	if(!document.getElementById('nickname').value.localeCompare('')) {
		alert('You must enter a nickname');
	} else if(!document.getElementById('msg_area').value.localeCompare('')) {
		alert('You can not send an empty message');
	} else {
		var txt = document.getElementById('msg_area').value;
		var author = document.getElementById('nickname').value;
		var timestamp = currentTime();
		var msg = theMsg(txt, author, timestamp);
		msg.isMy_message = true;
		addMsg(msg);
		store(messages, "Messages");
	}	
}

function addMsg(msg) {
	messages.push(msg);
	createItem(msg);
}

function createItem(msg) {
	var newLi = createNewLi(msg);
	var newMsg = createMsg(msg);
	var avatar = createAvatar();
	var author = createAuthor(msg.author);
	var msgTxt = createMsgTxt(msg);
	var edit_area = createEditArea();
	var delBtn = createDelBtn();
	var editBtn = createEditBtn();
	
	newMsg.appendChild(avatar);
	newMsg.appendChild(author);
	newMsg.appendChild(msgTxt);
	if(!msg.isDeleted && msg.isMy_message) {
		newMsg.appendChild(delBtn);
		newMsg.appendChild(editBtn);
	}
	newMsg.appendChild(edit_area);
	newLi.appendChild(newMsg);
	document.getElementById('msg_cnt').appendChild(newLi);
	var container = document.getElementsByClassName('container')[0];
	container.scrollTop = container.scrollHeight;
	
	document.getElementById('msg_area').value='';
}

function createNewLi(msg) {
	var newLi = document.createElement('li');
	if(msg.isMy_message) 
		newLi.className = "my-message";
	newLi.setAttribute("msg-id", msg.id);
	return newLi;
}

function createMsg(msg) {
	var newMsg = document.createElement('div');
	newMsg.className = "message";
	if(msg.isDeleted) 
		newMsg.className += " deleted";

	return newMsg;
}

function createAvatar() {
	var avatar = document.createElement('div');
	avatar.className = "message-avatar";
	return avatar;
}

function createAuthor(Msgauthor) {
	var author = document.createElement('div');
	author.className = "message-author";
	author.appendChild(document.createTextNode(Msgauthor));
	return author;
}

function createMsgTxt(msg) {
	var msgTxt = document.createElement('div');
	msgTxt.className = "message-text";
	msgTxt.appendChild(createTxt(msg));
	msgTxt.appendChild(createMessageDate(msg.timestamp));
	return msgTxt;
}

function createTxt(msg) {
	var txt = document.createElement('div');
	txt.className = "text";
	if(msg.isDeleted) {
		txt.appendChild(document.createTextNode("Deleted!"));
	} else {
		txt.appendChild(document.createTextNode(msg.txt));
	}
	return txt;
}

function createMessageDate(timestamp) {
	var messageDate = document.createElement('div');
	messageDate.className = "message-date";
	messageDate.appendChild(document.createTextNode(timestamp));
	return messageDate;
}

function createEditArea() {
	var edit_area = document.createElement('div');
	edit_area.className = "edit_area";
	edit_area.appendChild(createEditAreaText());
	edit_area.appendChild(createEditAreaBtn());
	return edit_area;
}

function createEditAreaText() {
	var edit_area_text = document.createElement('input');
	edit_area_text.type = "text";
	edit_area_text.className = "edit-field";
	return edit_area_text;
}

function createEditAreaBtn() {
	var edit_area_btn = document.createElement('input');
	edit_area_btn.type = "button";
	edit_area_btn.value = "OK";
	edit_area_btn.addEventListener("click", function(event) {
		var msg = this.parentElement.parentElement;
		editMsgText(msg);
	});
	return edit_area_btn;
}

function editMsgText(msg) {
	var id = msg.parentElement.attributes['msg-id'].value;
	var changedText = msg.getElementsByClassName('edit-field')[0].value;
	for(var i = 0; i < messages.length; i++) {
		if(messages[i].id != id)
			continue;
		
		messages[i].txt = changedText;		
	}
	store(messages, "Messages");
	
	msg.getElementsByClassName('text')[0].innerHTML = changedText;
	msg.getElementsByClassName('edit_area_on')[0].className = "edit_area";
}

function createDelBtn() {
	var delBtn = document.createElement('input');
	delBtn.type = "button";
	delBtn.addEventListener("click", function(event) {		
		var msg = this.parentElement;
		addDeletedClass(msg);		
	});
	delBtn.alt = "D";
	delBtn.className = "message-delete";
	return delBtn;
}

function addDeletedClass(msg) {
	var id = msg.parentElement.attributes['msg-id'].value;
	for(var i = 0; i < messages.length; i++) {
		if(messages[i].id != id)
			continue;
		
		messages[i].isDeleted = true;
	}
	store(messages, "Messages");
	
	msg.className = "message deleted";
	msg.getElementsByClassName('text')[0].innerHTML = 'Deleted!';
	msg.removeChild(msg.getElementsByClassName('message-edit')[0]);
	msg.removeChild(msg.getElementsByClassName('message-delete')[0]);
}

function createEditBtn() {
	var editBtn = document.createElement('input');
	editBtn.type = "button";
	editBtn.addEventListener("click", function(event) {
		var msg = this.parentElement;
		msg.getElementsByClassName("edit_area")[0].className = "edit_area_on";
		var edit_field = msg.getElementsByClassName('edit-field')[0];
		edit_field.value = msg.getElementsByClassName('text')[0].innerHTML;
	});
	editBtn.alt = "E";
	editBtn.className = "message-edit";
	return editBtn;
}

function theMsg(txt, author, timestamp) {
	return {
		txt: txt,
		author: author,
		timestamp: timestamp,
		id: uniqueId(),
		isMy_message: false,
		isDeleted: false
	};
}

function uniqueId() {
	var date = Date.now();
	var random = Math.random() * Math.random();

	return Math.floor(date * random).toString();
}

function currentTime() {
	var date = new Date();
	var hours = date.getHours();
	var minutes = date.getMinutes();
	var seconds = date.getSeconds();
	var dat = date.getDate();
	var month = date.getMonth() + 1;
	var year = date.getFullYear();
	
	return (hours > 9 ? hours : ("0" + hours)) + ":" +
			(minutes > 9 ? minutes : ("0" + minutes)) + ":" +
			(seconds > 9 ? seconds : ("0" + seconds)) + " " +
			(dat > 9 ? dat : ("0" + dat)) + "." +
			(month > 9 ? month : ("0" + month)) + "." +
			year;
}

function store(listToSave, key) {
	if(typeof(Storage) == "undefined") {
		alert('localStorage is not accessible');
		return;
	}

	localStorage.setItem(key, JSON.stringify(listToSave));
}

function restore(key) {
	if(typeof(Storage) == "undefined") {
		alert('localStorage is not accessible');
		return;
	}

	var item = localStorage.getItem(key);

	return item && JSON.parse(item);
}